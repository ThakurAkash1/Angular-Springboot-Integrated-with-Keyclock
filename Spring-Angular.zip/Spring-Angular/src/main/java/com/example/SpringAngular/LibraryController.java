package com.example.SpringAngular;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@SuppressWarnings("unused")
@CrossOrigin(origins = "*")
@RestController
public class LibraryController {

	@Autowired
	private LibraryRepository LibraryRepository;
	
	@RolesAllowed({"Admin","User"})
	@GetMapping("/books")
	public List<Library> getAllBooks(){
		return LibraryRepository.findAll();
	}		
	
	@RolesAllowed({"Admin"})
	@PostMapping("/books")
	public Library createBooks(@RequestBody Library Library) {
		return LibraryRepository.save(Library);
	}
	
	@RolesAllowed({"Admin"})
	@DeleteMapping("/books/{id}")
	public ResponseEntity<Map<String, Boolean>> deletebooks(@PathVariable Long id){
		Library books = LibraryRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Book not exist with id :" + id));
		
		LibraryRepository.delete(books);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	
	@RolesAllowed({"Admin"})
	 @PutMapping("/update/{id}")
   public ResponseEntity<Library> updateBooks(@PathVariable long id,@RequestBody Library book) {
		Library updateBooks =LibraryRepository.findById(id)
               .orElseThrow(() -> new ResourceNotFoundException("Book not exist with id: " + id));

		 updateBooks.setTitle(book.getTitle());
		 updateBooks.setImage(book.getImage());
		 updateBooks.setAuthorname(book.getAuthorname());
		 updateBooks.setDescription(book.getDescription());
		 updateBooks.setPrice(book.getPrice());

       LibraryRepository.save(updateBooks);

       return ResponseEntity.ok(updateBooks);
   }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	@RolesAllowed({"Admin"})
//	 @PutMapping("/books/{id}")
//    public ResponseEntity<Library> updateBooks(@PathVariable long id,@RequestBody Library book) {
//		Library updateBooks = LibraryRepository.findById(id)
//                .orElseThrow(() -> new ResourceNotFoundException("Book not exist with id: " + id));
//
//		 updateBooks.setTitle(book.getTitle());
//		 updateBooks.setImage(book.getImage());
//		 updateBooks.setAuthorname(book.getAuthorname());
//		 updateBooks.setDescription(book.getDescription());
//		 updateBooks.setPrice(book.getPrice());
//
//        LibraryRepository.save(updateBooks);
//
//        return ResponseEntity.ok(updateBooks);
//    }
		 
	
}

